﻿namespace Compr
{
    public class ComprConsts
    {
        public const string LocalizationSourceName = "Compr";
    }
}